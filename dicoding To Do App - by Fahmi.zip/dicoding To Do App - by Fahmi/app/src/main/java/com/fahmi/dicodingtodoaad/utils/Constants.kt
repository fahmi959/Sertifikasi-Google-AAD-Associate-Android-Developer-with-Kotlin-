package com.fahmi.dicodingtodoaad.utils

const val TASK_ID = "TASK_ID"
const val NOTIFICATION_CHANNEL_ID = "notify-task"
